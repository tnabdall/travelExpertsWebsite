            <footer>
                <!--Contains info fixed to bottom of page-->
                <a href="index.php" class="remove-blue-link inline-block">
                    <img class="centered-image small-image" src="images/Home_icon.png" alt="Home" title="Return to Home">
                </a>
                <p>&copy; Travel Experts 2019. All rights reserved. </p>
            </footer>
        </body>
    </div>

</html>