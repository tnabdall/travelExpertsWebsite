$(document).ready(function(){
    setTimeout('$("#container").css("opacity", 1)', 1000);
})