<?php
$urlLinks = array("http://www.tripadvisor.com"=>"Trip Advisor", 
"http://www.kayak.com"=>"Kayak",
"http://www.priceline.com"=>"Priceline",
"http://www.expedia.com"=>"Expedia",
"http://www.hipmunk.com"=>"Hipmunk",
"http://www.lonelyplanet.com"=>"Lonely Planet");
?>